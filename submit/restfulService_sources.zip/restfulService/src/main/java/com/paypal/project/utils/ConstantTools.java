package com.paypal.project.utils;

public class ConstantTools {

	public static final String PROP_FILENAME = "file.properties";
	public static final String PREFIX_REG = "regStr";
	public static final String PREFIX_FETCHID = "fetchID";
	public static final String PREFIX_FETCHALL = "fetchAll";
}
